from bs4 import BeautifulSoup

s=' 1'
if s.strip()=='':
    print ('s is null')
else:
    print('not null')